# Design Brief: Alex's Minecraft Staff Portfolio

## Tone & Purpose
Immersive, peaceful portfolio for a Minecraft staff professional. Night sky metaphor creates meditative context that contrasts with crisp information design. Calm, professional, not flashy.

## Visual Direction
Dark theme with deep space aesthetics. Falling stars animation creates motion without distraction. Glassmorphism cards feel modern and soft. Purple accent conveys creativity and professionalism.

## Color Palette (OKLCH, Dark Mode Only)

| Token | Value | Purpose |
|-------|-------|---------|
| background | 0.12 0.02 257 | Deep space blue-grey, night sky context |
| card | 0.18 0.01 260 | Glass-like, subtle depth for glassmorphism |
| primary/accent | 0.65 0.25 294 | Vibrant purple for buttons, highlights, CTAs |
| foreground | 0.95 0 0 | Clean white text |
| muted | 0.60 0 0 | Soft grey for secondary content |
| border | 0.28 0.02 260 | Low-opacity subtle dividers |
| input | 0.22 0.01 260 | Form fields, slightly elevated from background |

## Typography

| Layer | Font | Weight | Use |
|-------|------|--------|-----|
| Display | General Sans | 700 | Headings, hero, section titles |
| Body | DM Sans | 400–700 | Paragraphs, descriptions, body text |
| Mono | Geist Mono | 400–700 | Role labels, technical info, timestamps |

## Shape Language
- **Card radius**: 1.25rem (20px) — generous, soft, welcoming
- **Input radius**: 1.25rem — consistent with cards
- **Border style**: 1px solid with low opacity (`/0.3`) for subtlety
- **Depth**: Achieved via glassmorphism (`backdrop-filter: blur(10px)`) + subtle borders, not shadows

## Elevation & Depth

| Zone | Treatment |
|------|-----------|
| Background | Solid deep blue with animated falling stars (CSS animation) |
| Cards | Glass-morphism: `bg-card/40 backdrop-blur-md border border-border/30` |
| Hero | Full-width section, centered text, large typography |
| Content sections | Card-based grid layout, even spacing |
| Buttons | Purple glow on hover (`box-shadow: glow-purple-lg`), slight scale transform |
| Footer | Subtle `border-t border-border/20`, same card background |

## Structural Zones

| Zone | Background | Border | Purpose |
|------|-----------|--------|---------|
| Header | `bg-card/40 backdrop-blur` | `border-b border-border/30` | Navigation, logo, sticky top |
| Hero | `bg-background` | None | Full-width immersive intro |
| Content sections | Alternating `bg-card/30` cards | `border border-border/20` | Staff experience, strengths, availability |
| CTA buttons | `bg-primary` with `glow-purple` | None | Contact, link-out actions |
| Footer | `bg-card/20` | `border-t border-border/20` | Bottom info, minimal |

## Component Patterns
- **Primary button**: `bg-primary text-primary-foreground px-6 py-3 rounded-lg transition-smooth hover:glow-purple-lg hover:scale-105`
- **Secondary button**: `bg-card/40 border border-border hover:bg-card/60 transition-smooth`
- **Card**: `glass-card rounded-lg p-6 space-y-4`
- **Text link**: `text-primary hover:underline transition-smooth`
- **Input**: `glass-card px-4 py-2 focus:ring-2 focus:ring-primary`

## Motion & Animation

| Animation | Duration | Trigger | Effect |
|-----------|----------|---------|--------|
| Fall (stars) | Varies (10–30s) | Page load, infinite | Smooth vertical descent, full viewport height |
| Twinkle (stars) | 3s ease-in-out | Continuous | Opacity cycle: 0.3 → 1.0 → 0.3, repeats |
| Fade-in on scroll | 0.6s ease-out | Intersection observer | Subtle upward fade from 20px below |
| Button hover | 0.3s smooth | Hover | Glow intensifies, scale +5%, shadow expands |
| Icon hover | 0.3s smooth | Hover | Slight lift via `translateY(-2px)` |

## Differentiation & Signature Detail
**Purple soft-glow effect**: Buttons and highlights use `box-shadow: 0 0 24px 6px oklch(0.65 0.25 294 / 0.4)` — creates ambient, warm glow without neon harshness. Intensifies on hover, distinguishes CTAs from secondary interactions.

## Constraints & Anti-patterns
- ❌ No hard shadows or drop-shadow filters
- ❌ No harsh gradients or color transitions
- ❌ No busy animations or flickering
- ❌ No clashing accent colors; purple only
- ✅ Restrained, purposeful motion
- ✅ High contrast text for accessibility
- ✅ Generous spacing and breathing room
- ✅ Calm, meditative aesthetic throughout

## Layout & Spacing
- **Container max-width**: 1200px, centered
- **Section padding**: `py-16 lg:py-24` for vertical rhythm
- **Card spacing**: 1.5rem gap between items
- **Mobile-first breakpoints**: `sm: 640px`, `md: 768px`, `lg: 1024px`
- **Text width**: 65ch max for readability

## Responsive Design
- **Mobile**: Full-width cards, stacked layout, single-column
- **Tablet (768px+)**: 2-column grid, adjusted padding
- **Desktop (1024px+)**: Full multi-column layout, wider spacing
- **Mobile navigation**: Hamburger menu, full-screen overlay on small screens

## Accessibility
- **Color contrast**: All text meets WCAG AA (7:1+ on backgrounds)
- **Focus states**: Visible `:focus-visible` ring in primary purple
- **Semantic HTML**: Proper heading hierarchy, `<nav>`, `<main>`, `<footer>`
- **Alt text**: All images include descriptive alt attributes
- **Motion**: No auto-playing animations that loop excessively; user can pause via prefers-reduced-motion

