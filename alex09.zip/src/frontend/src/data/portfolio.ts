export interface ServerExperience {
  name: string;
  role: string;
  status: "Active" | "Resigned";
  members: string;
  highlight?: boolean;
}

export interface Strength {
  icon: string;
  title: string;
  description: string;
}

export const serverExperiences: ServerExperience[] = [
  {
    name: "FlowPvP",
    role: "Helper",
    status: "Resigned",
    members: "35,000+",
    highlight: true,
  },
  {
    name: "PirateMC",
    role: "Jr. Admin",
    status: "Resigned",
    members: "5,000+",
    highlight: true,
  },
  {
    name: "Legend's Web",
    role: "Community Manager",
    status: "Resigned",
    members: "2,000+",
    highlight: true,
  },
  {
    name: "RazeMC",
    role: "Sr. Mod",
    status: "Active",
    members: "1,700+",
  },
  {
    name: "Heartsteal",
    role: "Mod",
    status: "Resigned",
    members: "1,000+",
  },
  {
    name: "CripeeNetwork",
    role: "Sr. Mod",
    status: "Resigned",
    members: "850+",
  },
  {
    name: "WoodMC",
    role: "Sr. Mod",
    status: "Resigned",
    members: "800+",
  },
  {
    name: "StrafeMC",
    role: "Sr. Mod",
    status: "Resigned",
    members: "500+",
  },
  {
    name: "CookMC",
    role: "Admin",
    status: "Resigned",
    members: "450+",
  },
  {
    name: "UraniumMC",
    role: "Admin",
    status: "Resigned",
    members: "300+",
  },
  {
    name: "MineSweet",
    role: "Mod",
    status: "Resigned",
    members: "200+",
  },
];

export const strengths: Strength[] = [
  {
    icon: "🧠",
    title: "Multi-Server Experience",
    description:
      "Worked across 11+ servers of varying sizes, from small communities to 35,000+ member networks — building a broad understanding of server dynamics.",
  },
  {
    icon: "🕊️",
    title: "Calm Under Pressure",
    description:
      "Stays composed in tense situations and de-escalates conflicts with fairness and patience — never adding fuel to the fire.",
  },
  {
    icon: "⚖️",
    title: "Fair & Rule-Abiding",
    description:
      "Applies rules consistently and without bias, ensuring every player feels treated equally and the server stays safe and enjoyable.",
  },
  {
    icon: "🤝",
    title: "Community-Focused",
    description:
      "Genuinely cares about the people behind the screen — building trust and positive environments is at the heart of my staffing approach.",
  },
];

export const whyHireMe: string[] = [
  "Proven track record across 11+ servers including 35,000+ member communities",
  "Reached high-level roles like Admin, Community Manager, and Jr. Admin through hard work and dedication",
  "Consistently reliable — 4–5 hours daily, 25–35 hours weekly",
  "GMT+5:30 (IST) timezone coverage for servers needing active Asian region staff",
  "Calm, mature, and professional approach with a genuine passion for community building",
];

export const availability = {
  daily: "4–5 hours",
  weekly: "25–35 hours",
  timezone: "GMT +5:30 (IST)",
  note: "Minor fluctuations may occur due to school, but I always prioritize staying active and reliable online.",
};

export const discordLink =
  "https://discord.com/channels/@me/1454690471967330432";
