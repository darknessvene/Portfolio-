import { StarField } from "@/components/StarField";
import type { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div
      className="min-h-screen relative"
      style={{
        background:
          "radial-gradient(ellipse at 20% 50%, oklch(0.16 0.04 270 / 0.6) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, oklch(0.14 0.03 294 / 0.5) 0%, transparent 50%), oklch(0.10 0.015 257)",
      }}
    >
      <StarField />

      {/* Navbar */}
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-center px-4 py-4">
        <nav
          className="glass-card flex items-center gap-2 px-5 py-2.5 rounded-full border border-primary/20"
          data-ocid="main-nav"
        >
          <span className="font-display font-bold text-foreground text-sm tracking-wider mr-3">
            ALEX
          </span>
          <div className="w-px h-4 bg-border/50" />
          {[
            { label: "Home", href: "#home" },
            { label: "Experience", href: "#experience" },
            { label: "Strengths", href: "#strengths" },
            { label: "Contact", href: "#contact" },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              data-ocid={`nav-${item.label.toLowerCase()}`}
              className="text-xs font-body text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-full hover:bg-primary/10 transition-smooth"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </header>

      {/* Main content */}
      <main className="relative z-10 pt-20">{children}</main>
    </div>
  );
}
