import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  glowOnHover?: boolean;
  "data-ocid"?: string;
}

export function GlassCard({
  children,
  className,
  glowOnHover = false,
  "data-ocid": dataOcid,
}: GlassCardProps) {
  return (
    <div
      data-ocid={dataOcid}
      className={cn(
        "glass-card rounded-2xl p-6 transition-smooth",
        glowOnHover && "glow-purple-hover hover:border-primary/40",
        className,
      )}
    >
      {children}
    </div>
  );
}
