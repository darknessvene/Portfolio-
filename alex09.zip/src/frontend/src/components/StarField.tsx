import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  size: number;
  opacity: number;
  twinkleDuration: number;
  twinkleDelay: number;
  fallDuration: number;
  fallDelay: number;
  isFalling: boolean;
}

function generateStars(count: number): Star[] {
  return Array.from({ length: count }, () => {
    const isFalling = Math.random() < 0.3;
    return {
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: isFalling ? Math.random() * 1.5 + 0.5 : Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.6 + 0.2,
      twinkleDuration: Math.random() * 4 + 2,
      twinkleDelay: Math.random() * 5,
      fallDuration: Math.random() * 20 + 10,
      fallDelay: Math.random() * -30,
      isFalling,
    };
  });
}

export function StarField() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const stars = generateStars(160);
    const fragment = document.createDocumentFragment();

    for (const star of stars) {
      const el = document.createElement("div");
      const topVal = star.isFalling ? `-${star.size * 2}px` : `${star.y}%`;
      const heightVal = star.isFalling
        ? `${star.size * 6}px`
        : `${star.size}px`;
      const bg = star.isFalling
        ? "linear-gradient(to bottom, oklch(0.95 0.05 294), oklch(0.65 0.25 294 / 0))"
        : "oklch(0.92 0.05 280)";
      const anim = star.isFalling
        ? `fall ${star.fallDuration}s linear ${star.fallDelay}s infinite`
        : `twinkle ${star.twinkleDuration}s ease-in-out ${star.twinkleDelay}s infinite`;
      el.style.cssText = `
        position: absolute;
        left: ${star.x}%;
        top: ${topVal};
        width: ${star.size}px;
        height: ${heightVal};
        border-radius: ${star.isFalling ? "50% 50% 50% 50% / 20% 20% 80% 80%" : "50%"};
        background: ${bg};
        opacity: ${star.opacity};
        animation: ${anim};
        pointer-events: none;
        will-change: transform, opacity;
      `;
      fragment.appendChild(el);
    }

    container.appendChild(fragment);
    return () => {
      container.innerHTML = "";
    };
  }, []);

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className="fixed inset-0 overflow-hidden pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
