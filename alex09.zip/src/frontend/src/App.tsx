import { GlassCard } from "@/components/GlassCard";
import { Layout } from "@/components/Layout";
import { Section } from "@/components/Section";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  type ServerExperience,
  availability,
  discordLink,
  serverExperiences,
  strengths,
  whyHireMe,
} from "@/data/portfolio";

function RoleBadge({ role }: { role: string }) {
  const isHighRole = ["Admin", "Community Manager", "Jr. Admin"].some((r) =>
    role.includes(r),
  );
  return (
    <span
      className={`text-xs font-body px-2.5 py-0.5 rounded-full border font-medium ${
        isHighRole
          ? "bg-primary/20 text-primary border-primary/30"
          : "bg-secondary/60 text-muted-foreground border-border/40"
      }`}
      style={
        isHighRole
          ? { textShadow: "0 0 12px oklch(0.65 0.25 294 / 0.6)" }
          : undefined
      }
    >
      {role}
    </span>
  );
}

function StatusBadge({ status }: { status: ServerExperience["status"] }) {
  return (
    <span
      className={`text-xs font-body px-2 py-0.5 rounded-full ${
        status === "Active"
          ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
          : "bg-muted/40 text-muted-foreground border border-border/30"
      }`}
    >
      {status}
    </span>
  );
}

function ServerCard({ server }: { server: ServerExperience }) {
  return (
    <GlassCard
      glowOnHover={server.highlight}
      className={`flex flex-col gap-3 ${server.highlight ? "border-primary/25" : ""}`}
      data-ocid={`server-card-${server.name.toLowerCase().replace(/\s+/g, "-")}`}
    >
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-display font-semibold text-foreground text-sm leading-tight">
          {server.name}
        </h3>
        {server.highlight && (
          <span className="text-xs text-primary/70 font-body">★ Notable</span>
        )}
      </div>
      <RoleBadge role={server.role} />
      <div className="flex items-center justify-between mt-1">
        <span className="text-xs text-muted-foreground font-body">
          {server.members} members
        </span>
        <StatusBadge status={server.status} />
      </div>
    </GlassCard>
  );
}

export default function App() {
  return (
    <Layout>
      {/* Hero */}
      <Section
        id="home"
        className="min-h-[90vh] flex flex-col items-center justify-center px-4 text-center py-16"
        delay={100}
      >
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-1.5 border border-primary/20 mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-body text-muted-foreground">
              Available for Staff Positions
            </span>
          </div>

          <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight">
            <span className="text-foreground">Hi, I'm </span>
            <span
              className="text-primary"
              style={{
                textShadow: "0 0 40px oklch(0.65 0.25 294 / 0.4)",
              }}
            >
              Alex
            </span>
          </h1>

          <p className="font-display text-lg md:text-xl text-muted-foreground font-medium">
            Staff Member · Community Builder · 1+ Year of Experience
          </p>

          <p className="font-body text-base text-muted-foreground leading-relaxed max-w-xl mx-auto">
            I'm a Minecraft player who enjoys staffing and helping communities
            grow in a positive environment. I've worked across{" "}
            <span className="text-foreground font-medium">11+ servers</span>,
            maintaining rules, assisting players, and keeping gameplay fair and
            friendly.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <a href="#experience" data-ocid="hero-cta-experience">
              <Button
                className="rounded-full px-6 py-2.5 font-body font-medium transition-smooth hover:scale-105"
                style={{
                  background: "oklch(0.65 0.25 294)",
                  boxShadow: "0 0 20px 4px oklch(0.65 0.25 294 / 0.3)",
                }}
                data-ocid="hero-btn-experience"
              >
                View Experience
              </Button>
            </a>
            <a href="#contact" data-ocid="hero-cta-contact">
              <Button
                variant="outline"
                className="rounded-full px-6 py-2.5 font-body font-medium border-primary/30 text-primary hover:bg-primary/10 hover:scale-105 transition-smooth"
                data-ocid="hero-btn-contact"
              >
                Contact Me
              </Button>
            </a>
          </div>

          <div className="flex flex-wrap justify-center gap-6 pt-4 text-center">
            {[
              { label: "Servers Staffed", value: "11+" },
              { label: "Largest Community", value: "35K+" },
              { label: "Highest Role", value: "Admin / Community Manager" },
              { label: "Timezone", value: "GMT +5:30" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="flex flex-col items-center gap-1"
              >
                <span
                  className="font-display text-xl font-bold text-primary"
                  style={{ textShadow: "0 0 20px oklch(0.65 0.25 294 / 0.4)" }}
                >
                  {stat.value}
                </span>
                <span className="text-xs font-body text-muted-foreground">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* Staff Experience */}
      <Section
        id="experience"
        className="max-w-6xl mx-auto px-4 py-16"
        delay={0}
      >
        <div className="text-center mb-10">
          <Badge
            variant="outline"
            className="border-primary/30 text-primary/80 font-body mb-3"
          >
            Staff History
          </Badge>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Server Experience
          </h2>
          <p className="font-body text-muted-foreground mt-2 max-w-md mx-auto text-sm">
            From small communities to large networks — a track record of
            reliable, consistent staffing.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {serverExperiences.map((server, i) => (
            <div
              key={server.name}
              style={{
                opacity: 0,
                animation: `fadeInScroll 0.5s ease-out ${i * 60}ms forwards`,
              }}
            >
              <ServerCard server={server} />
            </div>
          ))}
        </div>
      </Section>

      {/* Strengths */}
      <Section
        id="strengths"
        className="max-w-5xl mx-auto px-4 py-16"
        delay={0}
      >
        <div className="text-center mb-10">
          <Badge
            variant="outline"
            className="border-primary/30 text-primary/80 font-body mb-3"
          >
            What I Bring
          </Badge>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Strengths
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {strengths.map((s, i) => (
            <GlassCard
              key={s.title}
              glowOnHover
              data-ocid={`strength-card-${i}`}
              className="flex gap-4 items-start"
            >
              <span className="text-2xl mt-0.5">{s.icon}</span>
              <div className="min-w-0">
                <h3 className="font-display font-semibold text-foreground mb-1">
                  {s.title}
                </h3>
                <p className="font-body text-sm text-muted-foreground leading-relaxed">
                  {s.description}
                </p>
              </div>
            </GlassCard>
          ))}
        </div>
      </Section>

      {/* Why Hire Me */}
      <Section className="max-w-3xl mx-auto px-4 py-16" delay={0} id="why-hire">
        <div className="text-center mb-10">
          <Badge
            variant="outline"
            className="border-primary/30 text-primary/80 font-body mb-3"
          >
            The Case
          </Badge>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Why Hire Me?
          </h2>
        </div>
        <GlassCard className="space-y-4">
          {whyHireMe.map((point) => (
            <div
              key={point}
              className="flex gap-3 items-start"
              data-ocid={`why-hire-item-${point.slice(0, 20).replace(/\s+/g, "-").toLowerCase()}`}
            >
              <span
                className="mt-0.5 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                style={{
                  background: "oklch(0.65 0.25 294 / 0.2)",
                  color: "oklch(0.65 0.25 294)",
                  border: "1px solid oklch(0.65 0.25 294 / 0.3)",
                }}
              >
                {(whyHireMe.indexOf(point) + 1).toString()}
              </span>
              <p className="font-body text-sm text-foreground/90 leading-relaxed">
                {point}
              </p>
            </div>
          ))}
        </GlassCard>
      </Section>

      {/* Availability */}
      <Section
        className="max-w-3xl mx-auto px-4 py-8"
        delay={0}
        id="availability"
      >
        <div className="text-center mb-8">
          <Badge
            variant="outline"
            className="border-primary/30 text-primary/80 font-body mb-3"
          >
            Schedule
          </Badge>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Availability
          </h2>
        </div>
        <GlassCard className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          {[
            { label: "Daily Hours", value: availability.daily },
            { label: "Weekly Hours", value: availability.weekly },
            { label: "Timezone", value: availability.timezone },
          ].map((item) => (
            <div key={item.label} className="flex flex-col items-center gap-2">
              <span
                className="font-display text-2xl font-bold text-primary"
                style={{ textShadow: "0 0 20px oklch(0.65 0.25 294 / 0.35)" }}
              >
                {item.value}
              </span>
              <span className="font-body text-xs text-muted-foreground uppercase tracking-wider">
                {item.label}
              </span>
            </div>
          ))}
        </GlassCard>
        <p className="font-body text-sm text-muted-foreground text-center mt-4 leading-relaxed max-w-md mx-auto">
          {availability.note}
        </p>
      </Section>

      {/* Contact */}
      <Section
        id="contact"
        className="max-w-2xl mx-auto px-4 py-16 text-center"
        delay={0}
      >
        <Badge
          variant="outline"
          className="border-primary/30 text-primary/80 font-body mb-4"
        >
          Get In Touch
        </Badge>
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
          Let's Work Together
        </h2>
        <p className="font-body text-muted-foreground text-sm mb-8 max-w-sm mx-auto leading-relaxed">
          Interested in having me join your staff team? Reach out on Discord —
          I'm always happy to chat and learn more about your server.
        </p>
        <GlassCard
          className="flex flex-col items-center gap-5"
          data-ocid="contact-card"
        >
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl"
            style={{
              background: "oklch(0.65 0.25 294 / 0.15)",
              border: "1px solid oklch(0.65 0.25 294 / 0.3)",
            }}
          >
            💬
          </div>
          <div className="text-center">
            <p className="font-display font-semibold text-foreground mb-1">
              Discord
            </p>
            <p className="font-body text-xs text-muted-foreground">
              Click below to send a direct message
            </p>
          </div>
          <a
            href={discordLink}
            target="_blank"
            rel="noopener noreferrer"
            data-ocid="contact-discord-btn"
          >
            <Button
              className="rounded-full px-8 py-2.5 font-body font-medium hover:scale-105 transition-smooth"
              style={{
                background: "oklch(0.65 0.25 294)",
                boxShadow: "0 0 24px 6px oklch(0.65 0.25 294 / 0.35)",
              }}
            >
              Contact on Discord
            </Button>
          </a>
        </GlassCard>
      </Section>
    </Layout>
  );
}
